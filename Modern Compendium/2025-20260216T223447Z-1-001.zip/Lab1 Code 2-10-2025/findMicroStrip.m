function output = findMicroStrip(choice,values)
%inputs in mm and ohms
if nargin < 2  % If no input arguments are given
    choice = '';
    while isempty(choice) || (~strcmp(choice, 'w') && ~strcmp(choice, 'h'))
        choice = input('Do you want to find w or h? [w/h]: ', 's');
        if ~strcmp(choice, 'w') && ~strcmp(choice, 'h')
            disp('Error: Please enter "w" or "h".');
        end
    end

    if choice == 'h'
       values = input('Please provide [w, Zo, er]: ');
    else
       values = input('Please provide [h, Zo, er]: ');
    end
end

% Extract variables

if choice == 'h'
    w = values(1);
    Zo = values(2);
    er = values(3);
elseif choice == 'w'
    h = values(1);
    Zo = values(2);
    er = values(3);
else
    error('Choice must be "w" or "h".');
end


% Initialize p and q
p = 0;
q = 0;

if (choice == 'h')
if (Zo >= (44-er*2))
    p = sqrt((er+1)/2)*Zo/60 + ((er-1)/(er+1))*(0.23+0.12/er);
    h = 8*exp(p)/(w*(exp(2*p)-2))
else
    q = (60*pi^2)/(Zo*sqrt(er));
    h = (2/(pi*w))*(q-1)-log(2*q-1) + ((er-1)/(2*er))*(log(q-1) ...
        + 0.29-0.52/er);
end
output = [q,h]
end

if (choice == 'w')
if (Zo >= (44-er*2))
    p = (Zo/60)*sqrt((er+1)/2) + ((er-1)/(er+1))*(0.23+(0.12/er));
    w = 8*h*exp(p)/(exp(2*p)-2)
else
    q = (60*pi^2)/(Zo*sqrt(er));
    w = ((2*h)/(pi))*(q-1)-log(2*q-1) + ((er-1)/(2*er))*(log(q-1) ...
        + 0.29-0.52/er)
end
output = [w];
end
end