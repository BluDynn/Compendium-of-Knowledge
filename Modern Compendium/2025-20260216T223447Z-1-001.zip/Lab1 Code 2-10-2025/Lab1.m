format short
format compact
clear
clc
close all

fontsize = 12;  % Set default font size for plots

set(groot, 'defaultAxesFontSize', fontsize);
set(groot, 'defaultTextFontSize', fontsize);
set(groot, 'defaultAxesFontName', 'Times New Roman');
set(groot, 'defaultTextFontName', 'Times New Roman');

%% Parameters
% for RG-58 Type Cable Solid PE and Tinned Copper

% Geometry (meters)
a = (0.9/2)*10^-3;          %m conductor diameter from data sheet RG-58
b = (2.95/2)*10^-3;         %m insulator diameter from data sheet RG-58

K_b = 2;                    %Braid Factor since cable doesnt use a cylinder, braid has 94% coverage
                            %set to 1 to assume perfect shield

% Frequency sweep
f = logspace(log10(1e6), log10(3e9), 2000);  % Hz
w = 2*pi*f;

sigma_c = 5.8*10^7; %S/m Conducivity of copper (assume tinned cu approximates cu
mu_c = 4*pi*10^-7;  %H/m
mu = 4*pi*10^-7;    %H/m
sigma = 1*10^-15.5; %S/m Solid PE ranges 10^-14 to 10^-17 
epsilon_r = 2.25;   %F/m Solid PE permittivity 2.25-2.35
epsilon_0 = 8.854*10^-12;

%% Equations

R_s = sqrt((pi*f*mu_c)/sigma_c);

R_prime = (R_s/(2*pi)) * (1/a+K_b/b);

L_prime = mu/(2*(pi)) * log(b/a);

G_prime = 2*pi*sigma / (log(b/a));
%G_prime = 0;

C_prime = (2*pi*epsilon_0*epsilon_r) / log(b/a); % F/m

% Transmission line quantities
gamma = sqrt( (R_prime + 1j*w*L_prime) .* (G_prime + 1j*w*C_prime) );  % 1/m
alpha = real(gamma);    % Np/m
beta  = imag(gamma);    % rad/m

Z0 = sqrt( (R_prime + 1j*w*L_prime) ./ (G_prime + 1j*w*C_prime) );     % ohms

% Convert attenuation to dB/m
%1Np = 10log e^2 = 8.686 dB
alpha_dB_per_m = 8.686 * alpha;

%% Prints
fprintf("L' = %.3e H/m\n", L_prime);
fprintf("C' = %.3e F/m\n", C_prime);
fprintf("Approx Z0 (low-loss) = %.2f ohms\n", sqrt(L_prime/C_prime));

%% Plots
%% |Z0| vs frequency
fig1 = figure;
semilogx(f, abs(Z0));
grid on;
xlabel('Frequency (Hz)');
ylabel('|Z_0| (\Omega)');
title('Characteristic impedance magnitude');

exportgraphics(fig1, 'Z0_vs_frequency.pdf', 'ContentType', 'vector');

%% Attenuation vs frequency
fig21 = figure;
semilogx(f, alpha_dB_per_m);
grid on;
xlabel('Frequency (Hz)');
ylabel('\alpha (dB/m)');
title('Attenuation vs frequency');

exportgraphics(fig21, 'attenuation_vs_frequency1.pdf', 'ContentType', 'vector');

fig22 = figure;
semilogx(f, alpha_dB_per_m*100);
grid on;
xlabel('Frequency (Hz)');
ylabel('\alpha (dB/100m)');
title('Attenuation vs frequency');

exportgraphics(fig22, 'attenuation_vs_frequency2.pdf', 'ContentType', 'vector');

%% Phase constant vs frequency
fig3 = figure;
semilogx(f, beta);
grid on;
xlabel('Frequency (Hz)');
ylabel('\beta (rad/m)');
title('Phase constant vs frequency');

exportgraphics(fig3, 'beta_vs_frequency.pdf', 'ContentType', 'vector');

%% Part 6

f = 1*10^9;
w = 2*pi*f;

R_s = sqrt((pi*f*mu_c)/sigma_c);

R_prime = (R_s/(2*pi)) * (1/a+K_b/b);

L_prime = mu/(2*(pi)) * log(b/a);

G_prime = 2*pi*sigma / (log(b/a));

C_prime = (2*pi*epsilon_0*epsilon_r) / log(b/a); % F/m

% Transmission line quantities
gamma = sqrt( (R_prime + 1j*w*L_prime) .* (G_prime + 1j*w*C_prime) );  % 1/m
alpha = real(gamma);    % Np/m
beta  = imag(gamma);    % rad/m

Z0 = sqrt( (R_prime + 1j*w*L_prime) ./ (G_prime + 1j*w*C_prime) );     % ohms

% Convert attenuation to dB/m
alpha_dB_per_100m = 8.686 * alpha * 100

%discrepancies in nominal value come from braided shield and tolerances to
%the real world product as in radii a and b are inconsistent or material
%properties are not exact.

%% Part 8

%inputs should be in mm and ohms. Solves for height of substrate or width
%of trace.

%FR-4 MG chemcials model 575 is 1/16th inch or 1.5875mm thick
%FR-4 dK = 4.2 at 1GHz
%o/p width should be 3.1363
%micro strip online calc gives ~3.1mm (due to trace height 't' at 35um)
out = findMicroStrip('w', [1.5875, 50, 4.2]);
width = out;